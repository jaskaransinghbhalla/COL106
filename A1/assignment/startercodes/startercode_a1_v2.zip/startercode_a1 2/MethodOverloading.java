package com.gradescope.assignment1;

import com.gradescope.assignment1.AbstractMethodOverloading;
import java.lang.Math;

public class MethodOverloading extends AbstractMethodOverloading {
    /*
     * To be filled in by the student
     * Implement all the three overloaded methods here:
     *      Method name : "calculate"
     *      Return type : "double"
     *      And method should be "public" member of the class.
     */
}
