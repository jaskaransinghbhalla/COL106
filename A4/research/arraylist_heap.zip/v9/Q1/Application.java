import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Application extends Tree {

  public void insert(String s) {
    // TO be completed by students
    insert(s);
    //Creating the File object

  }

  public int increment(String s) {
    // TO be completed by students
    return 0;
  }

  public int decrement(String s) {
    // TO be completed by students
    return 0;
  }

  public void buildTree(String fileName) {
    // TO be completed by students
    try {
      File file = new File("test");
      //Creating a Scanner object
      Scanner sc = new Scanner(file);
      //StringBuffer to store the contents
      StringBuffer sb = new StringBuffer();
      //Appending each line to the buffer
      while (sc.hasNext()) {
        sb.append(" " + sc.nextLine());
      }

      String word = "";

      for (int i = 0; i < sb.length(); i++) {
        if (sb.charAt(i) == 32) {
          insert(word);
          word = "";
        } else {
          word = word + sb.charAt(i);
        }
      }
    } catch (Exception e) {}
  }

  public int cumulativeFreq(String s1, String s2) {
    // TO be completed by students
    return 0;
  }

  public String maxFreq(String s1, String s2) {
    // TO be completed by students
    return "";
  }

  public static void main(String[] args) {
    Application app = new Application();
    app.buildTree("./test");
  }
}
