import java.util.ArrayList;
public class Tree {

    public TreeNode root;

    public Tree() {
        root = null;
    }

    public void insert(String s) {
        // TO be completed by students
        if (root == null) {
            root = new TreeNode();
            root.s.add(s);
            root.val.add(1);
        } else {
            insert_r(root, null, s);
        }
    }
    private void insert_r(TreeNode x, TreeNode y, String some) {
        boolean leaf  = false;
        if (x.children.size() == 0) {
            leaf = true;
            int i = 0;
            for (String e: x.s) {
                if (some.compareTo(e)<0){
                    break;
                } else {
                    i+=1;
                }
            }
            if (i == x.s.size()) {
                x.s.add(some);
                x.val.add(1);
            } else {
                x.s.add(i, some);
                x.val.add(i, 1);
            }
        } else {
            int j = 0;
            for (String jk: x.s) {
                if (some.compareTo(jk) < 0) {
                    break;
                } else {
                    j += 1;
                }
            }
            insert_r(x.children.get(j), x, some);
        }
        if (x.s.size() == 4) {
            TreeNode p = new TreeNode();
            p.height = x.height;
            p.s.add(x.s.get(2));
            p.s.add(x.s.get(3));
            p.val.add(x.val.get(2));
            p.val.add(x.val.get(3));
            p.height = x.height;
            ArrayList<String> r = x.s;
            ArrayList<Integer> r1 = x.val;
            x.s = new ArrayList<String>();
            x.val = new ArrayList<Integer>();
            x.s.add(r.get(0));
            // x.s.add(r.get(1));
            x.val.add(r1.get(0));
            // x.val.add(r1.get(1));
            if (!leaf) {
                p.children.add(x.children.get(2));
                p.children.add(x.children.get(3));
                p.children.add(x.children.get(4));
                ArrayList<TreeNode> r2 = x.children;
                x.children = new ArrayList<TreeNode>();
                x.children.add(r2.get(0));
                x.children.add(r2.get(1));
            }
            if (y != null) {
                int index = 0;
                for (TreeNode o: y.children) {
                    if (o!=x) {
                        index+=1;
                    } else {
                        break;
                    }
                }
                int u = 0;
                for (String ew: y.s) {
                    if (r.get(1).compareTo(ew)<0){
                        break;
                    } else {
                        u+=1;
                    }
                }
                if (u == y.s.size()) {
                    y.s.add(r.get(1));
                    y.val.add(r1.get(1));
                } else {
                    y.s.add(u, r.get(1));
                    y.val.add(u, r1.get(1));
                }
                if ((index+1) == y.children.size()) {
                    y.children.add(p);
                } else {
                    y.children.add(index+1, p);
                }
            } else {
                TreeNode wowow = new TreeNode();
                wowow.children.add(x);
                wowow.children.add(p);
                wowow.s.add(r.get(1));
                wowow.val.add(r1.get(1));
                int h = root.height;
                root = wowow;
                root.height = h+1;
            }
        }
    }
    public boolean delete(String s) {
        // TO be completed by students
        if (root != null) {
            return delete_r(root, null, s);
        } else {
            return false;
        }
    }
    private boolean delete_r(TreeNode x, TreeNode y, String del) {
        int index = 0;
        boolean set = false;
        for (String s: x.s) {
            if(del.compareTo(s) < 0) {
                if (x.children.size() != 0) {
                    set = delete_r(x.children.get(index), x, del);
                } else {
                    return false;
                }
                break;
            } else if (del.compareTo(s) == 0) {
                set = true;
                if (x.children.size() != 0) {
                    TreeNode k = x.children.get(index);
                    while (k.children.size() != 0) {
                        k = k.children.get(k.s.size());
                    }
                    String something = k.s.get(k.s.size() - 1);
                    int value = k.val.get(k.s.size() - 1);
                    x.s.set(index, something);
                    x.val.set(index, value);
                    delete_r(x.children.get(index), x, something);
                } else {
                    x.s.remove(index);
                    x.val.remove(index);
                }
                break;
            } else {
                index += 1;
                if (index == x.s.size()) {
                    if (x.children.size() != 0) {
                        set = delete_r(x.children.get(index), x, del);
                        break;
                    } else {
                        return false;
                    }
                }
            }
        }
        if (x.s.size()  == 0) {
            if (y != null) {
                if (y.children.get(0) == x) {
                    //borrow from 1
                    String par_s = y.s.get(0);
                    int par_v = y.val.get(0);
                    String sib_s = y.children.get(1).s.get(0);
                    int sib_v = y.children.get(1).val.get(0);
                    x.s.add(par_s);
                    x.val.add(par_v);
                    y.s.remove(0);
                    y.val.remove(0);
                    if (y.children.get(1).s.size() == 1) {
                        for (TreeNode t: y.children.get(1).children) {
                            x.children.add(t);
                        }
                        x.s.add(sib_s);
                        x.val.add(sib_v);
                        y.children.remove(1);
                    } else {
                        if (y.children.get(1).children.size() > 0) {
                            x.children.add(y.children.get(1).children.get(0));
                            y.children.get(1).children.remove(0);
                        }
                        y.s.add(0, sib_s);
                        y.val.add(0, sib_v);
                        y.children.get(1).s.remove(0);
                        y.children.get(1).val.remove(0);
                    }
                } else {
                    int ere = 0;
                    for (TreeNode www: y.children) {
                        if (www != x) {
                            ere += 1;
                        } else {
                            break;
                        }
                    }
                    String par_s = y.s.get(ere - 1);
                    int par_v = y.val.get(ere - 1);
                    int sib_size = y.children.get(ere - 1).s.size();
                    String sib_s = y.children.get(ere - 1).s.get(sib_size - 1);
                    int sib_v = y.children.get(ere - 1).val.get(sib_size - 1);
                    x.s.add(par_s);
                    x.val.add(par_v);
                    if (sib_size == 1) {
                        y.s.remove(ere - 1);
                        y.val.remove(ere - 1);
                        if (y.children.get(ere - 1).children.size() > 0) {
                            x.children.add(0, y.children.get(ere - 1).children.get(1));
                            x.children.add(0, y.children.get(ere - 1).children.get(0));
                        }
                        x.s.add(0, sib_s);
                        x.val.add(0, sib_v);
                        y.children.remove(ere - 1);
                    } else {
                        y.s.set(ere - 1, sib_s);
                        y.val.set(ere - 1, sib_v);
                        if (y.children.get(ere - 1).children.size() > 0) {
                            x.children.add(0, y.children.get(ere - 1).children.get(sib_size));
                            y.children.get(ere - 1).children.remove(sib_size);
                        }
                        y.children.get(ere-1).s.remove(sib_size - 1);
                        y.children.get(ere-1).val.remove(sib_size - 1);
                    }
                    //borrow from ere - 1
                }
            } else {
                if (x.children.size() > 0) {
                    root = x.children.get(0);
                }
            }
        }
        return set;
    }
    public boolean search(String s) {
        // TO be completed by students
        if (root == null) {
            return false;
        } else {
            return search_r(root, s);
        }
    }
    private boolean search_r (TreeNode x, String string) {
        int i = 0;
        for (String some: x.s) {
            if (string.compareTo(some)<0){
                break;
            } else if(string.compareTo(some)==0) {
                return true;
            } else {
                i+=1;
            }
        }
        if (x.children.size() == 0) {
            return false;
        } else {
            return search_r(x.children.get(i), string);
        }
    }
    public int increment(String s) {
        // TO be completed by students
        if (root == null) {
            return Integer.MIN_VALUE;
        } else {
            return increment_r(root, s);
        }
    }
    private int increment_r(TreeNode x, String how) {
        int ret = 0;
        int i = 0;
        for (String some: x.s) {
            if (how.compareTo(some)<0){
                break;
            } else if(how.compareTo(some)==0) {
                ret = x.val.get(i) + 1;
                x.val.set(i, ret);
                return ret;
            } else {
                i+=1;
            }
        }
        return increment_r(x.children.get(i), how);
    }
    public int decrement(String s) {
        // TO be completed by students
        if (root == null) {
            return Integer.MIN_VALUE;
        } else {
            return decrement_r(root, s);
        }
    }
    private int decrement_r(TreeNode x, String how) {
        int ret = 0;
        int i = 0;
        for (String some: x.s) {
            if (how.compareTo(some)<0){
                break;
            } else if(how.compareTo(some)==0) {
                ret = x.val.get(i) - 1;
                x.val.set(i, ret);
                return ret;
            } else {
                i+=1;
            }
        }
        return decrement_r(x.children.get(i), how);
    }
    public int getHeight() {
        // TO be completed by students
        return root.height;
    }

    public int getVal(String s) {
        // TO be completed by students
        if (root == null) {
            return Integer.MIN_VALUE;
        } else {
            return getVal_r(root, s);
        }
    }
    private int getVal_r(TreeNode x, String how) {
        int i = 0;
        for (String some: x.s) {
            if (how.compareTo(some)<0){
                break;
            } else if(how.compareTo(some)==0) {
                return x.val.get(i);
            } else {
                i+=1;
            }
        }
        return getVal_r(x.children.get(i), how);
    }
}