import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Application extends Tree {

    public void insert(String s) {
        // TO be completed by students
        if (root == null) {
            root = new TreeNode();
            root.s.add(s);
            root.val.add(1);
        } else {
            insert_r(root, null, s);
        }
    }
    private void insert_r(TreeNode x, TreeNode y, String some) {
        boolean leaf  = false;
        if (x.children.size() == 0) {
            leaf = true;
            int i = 0;
            for (String e: x.s) {
                if (some.compareTo(e)<0){
                    break;
                } else {
                    i+=1;
                }
            }
            if (i == x.s.size()) {
                x.s.add(some);
                x.val.add(1);
            } else {
                x.s.add(i, some);
                x.val.add(i, 1);
            }
        } else {
            int j = 0;
            for (String jk: x.s) {
                if (some.compareTo(jk) < 0) {
                    break;
                } else {
                    j += 1;
                }
            }
            insert_r(x.children.get(j), x, some);
        }
        if (x.s.size() == 4) {
            TreeNode p = new TreeNode();
            p.height = x.height;
            p.s.add(x.s.get(2));
            p.s.add(x.s.get(3));
            p.val.add(x.val.get(2));
            p.val.add(x.val.get(3));
            p.height = x.height;
            p.max_s = "";
            p.max_value = Integer.MIN_VALUE;
            p.count = (x.val.get(2) + x.val.get(3));
            ArrayList<String> r = x.s;
            ArrayList<Integer> r1 = x.val;
            x.s = new ArrayList<String>();
            x.val = new ArrayList<Integer>();
            x.s.add(r.get(0));
            // x.s.add(r.get(1));
            x.val.add(r1.get(0));
            x.count = r1.get(0);
            x.max_s = "";
            x.max_value = Integer.MIN_VALUE;
            if (!leaf) {
                p.children.add(x.children.get(2));
                p.children.add(x.children.get(3));
                p.children.add(x.children.get(4));
                p.count += x.children.get(2).count + x.children.get(3).count + x.children.get(4).count;
                int i = 0;
                while (i <= p.s.size()) {
                    if (p.children.get(i).max_value > p.max_value) {
                        p.max_s = p.children.get(i).max_s;
                        p.max_value = p.children.get(i).max_value;
                    }
                    if (i < p.s.size()) {
                        if (p.val.get(i) > p.max_value) {
                            p.max_s = p.s.get(i);
                            p.max_value = p.val.get(i);
                        }
                    }
                    i += 1;
                }
                ArrayList<TreeNode> r2 = x.children;
                x.children = new ArrayList<TreeNode>();
                x.children.add(r2.get(0));
                x.children.add(r2.get(1));
                x.count+=r2.get(0).count + r2.get(1).count;
                i = 0;
                while (i <= x.s.size()) {
                    if (x.children.get(i).max_value > x.max_value) {
                        x.max_s = x.children.get(i).max_s;
                        x.max_value = x.children.get(i).max_value;
                    }
                    if (i < x.s.size()) {
                        if (x.val.get(i) > x.max_value) {
                            x.max_s = x.s.get(i);
                            x.max_value = x.val.get(i);
                        }
                    }
                    i += 1;
                }
            } else {
                int i = 0;
                while (i < x.s.size()) {
                    if (x.val.get(i) > x.max_value) {
                        x.max_s = x.s.get(i);
                        x.max_value = x.val.get(i);
                    }
                    i += 1;
                }
                i = 0;
                while (i < p.s.size()) {
                    if (p.val.get(i) > p.max_value) {
                        p.max_s = p.s.get(i);
                        p.max_value = p.val.get(i);
                    }
                    i += 1;
                }
            }
            if (y != null) {
                int index = 0;
                for (TreeNode o: y.children) {
                    if (o!=x) {
                        index+=1;
                    } else {
                        break;
                    }
                }
                int u = 0;
                for (String ew: y.s) {
                    if (r.get(1).compareTo(ew)<0){
                        break;
                    } else {
                        u+=1;
                    }
                }
                if (u == y.s.size()) {
                    y.s.add(r.get(1));
                    y.val.add(r1.get(1));
                } else {
                    y.s.add(u, r.get(1));
                    y.val.add(u, r1.get(1));
                }
                if ((index+1) == y.children.size()) {
                    y.children.add(p);
                } else {
                    y.children.add(index+1, p);
                }
            } else {
                TreeNode wowow = new TreeNode();
                wowow.children.add(x);
                wowow.children.add(p);
                wowow.s.add(r.get(1));
                wowow.val.add(r1.get(1));
                wowow.count = x.count + p.count + wowow.val.get(0);
                if (x.max_value >= wowow.val.get(0)) {
                    wowow.max_s = x.max_s;
                    wowow.max_value = x.max_value;
                } else if (wowow.val.get(0) >= p.max_value) {
                    wowow.max_s = wowow.s.get(0);
                    wowow.max_value = wowow.val.get(0);
                } else {
                    wowow.max_s = p.max_s;
                    wowow.max_value = p.max_value;
                }
                int h = root.height;
                root = wowow;
                root.height = h+1;
            }
        } else {
            x.count += 1;
            if (leaf) {
                for (int d = 0; d < x.s.size(); d++) {
                    if (x.val.get(d) > x.max_value) {
                        x.max_value = x.val.get(d);
                        x.max_s = x.s.get(d);
                    }
                }
            } else {
                x.max_value = Integer.MIN_VALUE;
                x.max_s = "";
                int i = 0;
                while (i <= x.s.size()) {
                    if (x.children.get(i).max_value > x.max_value) {
                        x.max_s = x.children.get(i).max_s;
                        x.max_value = x.children.get(i).max_value;
                    }
                    if (i < x.s.size()) {
                        if (x.val.get(i) > x.max_value) {
                            x.max_s = x.s.get(i);
                            x.max_value = x.val.get(i);
                        }
                    }
                    i += 1;
                }
            }
        }
    }

    public int increment(String s){
        // TO be completed by students
        if (root == null) {
            return Integer.MIN_VALUE;
        } else {
            return increment_r(root, s);
        }
    }
    private int increment_r(TreeNode x, String how) {
        int ret = 0;
        int i = 0;
        for (String some: x.s) {
            if (how.compareTo(some)<0){
                break;
            } else if(how.compareTo(some)==0) {//if found as an internal node, make changes here itself
                x.count += 1;
                ret = x.val.get(i) + 1;
                x.val.set(i, ret);
                if (x.children.size() == 0) {
                    for (int d = 0; d < x.s.size(); d++) {
                        if (x.val.get(d) > x.max_value) {
                            x.max_value = x.val.get(d);
                            x.max_s = x.s.get(d);
                        }
                    }
                } else {
                    x.max_value = Integer.MIN_VALUE;
                    x.max_s = "";
                    int j = 0;
                    while (j <= x.s.size()) {
                        if (x.children.get(j).max_value > x.max_value) {
                            x.max_s = x.children.get(j).max_s;
                            x.max_value = x.children.get(j).max_value;
                        }
                        if (j < x.s.size()) {
                            if (x.val.get(j) > x.max_value) {
                                x.max_s = x.s.get(j);
                                x.max_value = x.val.get(j);
                            }
                        }
                        j += 1;
                    }
                }
                return ret;
            } else {
                i+=1;
            }
        }
        int op = increment_r(x.children.get(i), how);
        x.count += 1;
        if (x.children.size() == 0) {
            for (int d = 0; d < x.s.size(); d++) {
                if (x.val.get(d) > x.max_value) {
                    x.max_value = x.val.get(d);
                    x.max_s = x.s.get(d);
                }
            }
        } else {
            x.max_value = Integer.MIN_VALUE;
            x.max_s = "";
            int j = 0;
            while (j <= x.s.size()) {
                if (x.children.get(j).max_value > x.max_value) {
                    x.max_s = x.children.get(j).max_s;
                    x.max_value = x.children.get(j).max_value;
                }
                if (j < x.s.size()) {
                    if (x.val.get(j) > x.max_value) {
                        x.max_s = x.s.get(j);
                        x.max_value = x.val.get(j);
                    }
                }
                j += 1;
            }
        }
        return op;
    }

    public int decrement(String s) {
        // TO be completed by students
        if (root == null) {
            return Integer.MIN_VALUE;
        } else {
            return decrement_r(root, s);
        }
    }
    private int decrement_r(TreeNode x, String how) {
        int ret = 0;
        int i = 0;
        for (String some: x.s) {
            if (how.compareTo(some)<0){
                break;
            } else if(how.compareTo(some)==0) {//if found as an internal node, make changes here itself
                x.count -= 1;
                ret = x.val.get(i) - 1;
                x.val.set(i, ret);
                if (x.children.size() == 0) {
                    x.max_s = "";
                    x.max_value = Integer.MIN_VALUE;
                    for (int d = 0; d < x.s.size(); d++) {
                        if (x.val.get(d) > x.max_value) {
                            x.max_value = x.val.get(d);
                            x.max_s = x.s.get(d);
                        }
                    }
                } else {
                    x.max_value = Integer.MIN_VALUE;
                    x.max_s = "";
                    int j = 0;
                    while (j <= x.s.size()) {
                        if (x.children.get(j).max_value > x.max_value) {
                            x.max_s = x.children.get(j).max_s;
                            x.max_value = x.children.get(j).max_value;
                        }
                        if (j < x.s.size()) {
                            if (x.val.get(j) > x.max_value) {
                                x.max_s = x.s.get(j);
                                x.max_value = x.val.get(j);
                            }
                        }
                        j += 1;
                    }
                }
                return ret;
            } else {
                i+=1;
            }
        }
        int op = decrement_r(x.children.get(i), how);
        x.count -= 1;
        if (x.children.size() == 0) {
            x.max_s = "";
            x.max_value = Integer.MIN_VALUE;
            for (int d = 0; d < x.s.size(); d++) {
                if (x.val.get(d) > x.max_value) {
                    x.max_value = x.val.get(d);
                    x.max_s = x.s.get(d);
                }
            }
        } else {
            x.max_value = Integer.MIN_VALUE;
            x.max_s = "";
            int j = 0;
            while (j <= x.s.size()) {
                if (x.children.get(j).max_value > x.max_value) {
                    x.max_s = x.children.get(j).max_s;
                    x.max_value = x.children.get(j).max_value;
                }
                if (j < x.s.size()) {
                    if (x.val.get(j) > x.max_value) {
                        x.max_s = x.s.get(j);
                        x.max_value = x.val.get(j);
                    }
                }
                j += 1;
            }
        }
        return op;
    }

    public void buildTree(String fileName){
        // TO be completed by students
        try {
            File f = new File(fileName);
            Scanner s = new Scanner(f);
            while(s.hasNext()) {
                String x = s.next(); //removes spaces and newline characters easily
                if (this.search(x)) {
                    this.increment(x);
                } else {
                    this.insert(x);
                }
            }
            s.close();
        } catch (Exception e) {
            // System.out.println("Something happened.");
        }
    }

    public int cumulativeFreq(String s1, String s2){
        // TO be completed by students
        return cumulativeFreqHelper(root, s1, s2);
    }
    private int cumulativeFreqHelper(TreeNode x, String some1, String some2) {
        if (x == null) {
            return 0;
        }
        boolean leaf = x.children.size() == 0;
        int j = x.s.size();
        if (leaf && (some1.compareTo(x.s.get(0)) <= 0) && (some2.compareTo(x.s.get(j - 1)) >= 0)) {
            return x.count;
        }
        int i = 0;
        int ret = 0;
        while (i < j) {
            if ((some1.compareTo(x.s.get(i)) < 0) && !(leaf)) {
                if ((i > 0) && (x.s.get(i - 1).compareTo(some1) >= 0) && (x.s.get(i).compareTo(some2) <= 0)) {
                    ret += x.children.get(i).count;
                } else {
                    ret += cumulativeFreqHelper(x.children.get(i), some1, some2);
                }
            }
            if (some2.compareTo(x.s.get(i)) < 0) {
                break;
            }
            if ((some1.compareTo(x.s.get(i)) <= 0) && (some2.compareTo(x.s.get(i)) >= 0)){
                ret += x.val.get(i);
            }
            i += 1;
            if (i == j) {
                if ((some2.compareTo(x.s.get(i-1)) > 0) && !(leaf)) {
                    ret += cumulativeFreqHelper(x.children.get(i), some1, some2);
                }
            }
        }
        return ret;
    }

    public String maxFreq(String s1, String s2){
        // TO be completed by students
        return maxFreqHelper(root, s1, s2);
    }
    private String maxFreqHelper(TreeNode x, String some1, String some2) {
        if (x == null) {
            return "";
        }
        boolean leaf = x.children.size() == 0;
        int j = x.s.size();
        if ((some1.compareTo(x.max_s) <= 0) && (some2.compareTo(x.max_s) >= 0)) {
            return x.max_s;
        }
        int i = 0;
        String ret = "";
        int maxval = Integer.MIN_VALUE;
        while (i < j) {//since going inorder, no need to check if temp < ret additionally
            if ((some1.compareTo(x.s.get(i)) < 0) && !(leaf)) {
                String temp = maxFreqHelper(x.children.get(i), some1, some2);
                if (!(temp.equals(""))) {
                    int tempval = getVal(temp);
                    if ((tempval > maxval)){
                        ret = temp;
                        maxval = tempval;
                    }
                }
            }
            if (some2.compareTo(x.s.get(i)) < 0) {
                break;
            }
            if ((some1.compareTo(x.s.get(i)) <= 0) && (some2.compareTo(x.s.get(i)) >= 0) && (x.val.get(i)) > maxval){
                ret = x.s.get(i);
                maxval = x.val.get(i);
            }
            i += 1;
            if (i == j) {
                if ((some2.compareTo(x.s.get(i-1)) > 0) && !(leaf)) {
                    String temp = maxFreqHelper(x.children.get(i), some1, some2);
                    if (!(temp.equals(""))) {
                        int tempval = getVal(temp);
                        if ((tempval > maxval)){
                            ret = temp;
                            maxval = tempval;
                        }
                    }
                }
            }
        }
        return ret;
    }
}