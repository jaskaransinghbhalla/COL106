public class Application extends Tree {

    public void insert(String s){
        // TO be completed by students
    }

    public int increment(String s){
        // TO be completed by students
        return 0;
    }

    public int decrement(String s){
        // TO be completed by students
        return 0;
    }

    public void buildTree(String fileName){
        // TO be completed by students
    }

    static int cumulativeFreq(String s1, String s2){
        // TO be completed by students
        return 0;
    }

    static String maxFreq(String s1, String s2){
        // TO be completed by students
        return "";
    }

}

