import java.util.ArrayList;

// import java.util.Collections;

public class SkipList {

  public SkipListNode head;
  public SkipListNode tail;
  public int height;
  public Randomizer randomizer;
  private final int NEG_INF = Integer.MIN_VALUE;
  private final int POS_INF = Integer.MAX_VALUE;

  SkipList() {
    /*
     * DO NOT EDIT THIS FUNCTION
     */
    this.head = new SkipListNode(NEG_INF, 1);
    this.tail = new SkipListNode(POS_INF, 1);
    this.head.next.add(0, this.tail);
    this.tail.next.add(0, null);
    this.height = 1;
    this.randomizer = new Randomizer();
  }

  public boolean delete(int num) {
    if (search(num)) {
      int h = this.height;

      ArrayList<SkipListNode> prearr = new ArrayList<>();
      ArrayList<SkipListNode> succarr = new ArrayList<>();
      SkipListNode pre = this.head;
      SkipListNode succ = null;
      SkipListNode temp;

      SkipListNode n = null;

      while (h >= 1) {
        int level = h - 1;
        temp = pre;
        while (temp.value < num) {
          pre = temp;
          temp = temp.next.get(level);
        }
        prearr.add(pre);
        h--;
        if (temp.value == num) {
          n = temp;
          succarr.add(pre.next.get(level).next.get(level));
          break;
        } else {
          succarr.add(pre.next.get(level));
        }
      }

      while (h >= 1) {
        int level = h - 1;
        while (pre.next.get(level) != n) {
          pre = pre.next.get(level);
        }
        prearr.add(pre);
        succarr.add(pre.next.get(level).next.get(level));
        h--;
      }

      for (int level = n.height - 1; level >= 0; level--) {
        // Get Predecessor
        pre = prearr.get(prearr.size() - 1 - level);
        succ = succarr.get(succarr.size() - 1 - level);
        pre.next.set(level, succ);

        if (this.head.next.get(level) == this.tail) {
          this.head.next.remove(level);
          this.tail.next.remove(level);
          this.head.height--;
          this.tail.height--;
          this.height--;
        }
      }
      return true;
    }
    return false;
  }

  public boolean search(int num) {
    int h = this.height;

    SkipListNode pre = this.head;
    SkipListNode succ = this.tail;
    SkipListNode temp;

    while (h >= 1) {
      int level = h - 1;
      temp = pre;
      while (temp.next.get(level) != null && temp.value < succ.value) {
        if (temp.value == num) {
          return true;
        }
        if (temp.value < num) {
          pre = temp;
          temp = temp.next.get(level);
        }
        if (temp.value > num) {
          succ = temp;
        }
      }
      h--;
    }
    return false;
  }

  public Integer upperBound(int num) {
    int k = this.height;
    SkipListNode prev = this.head;
    SkipListNode temp = new SkipListNode(Integer.MAX_VALUE, 1);

    while (k >= 1) {
      int level = k - 1;
      temp = prev;
      while (temp.next.get(level) != null) {
        if (temp.value <= num) {
          prev = temp;
          temp = temp.next.get(level);
        } else {
          break;
        }
      }
      k--;
    }
    return temp.value;
  }

  public void insert(int num) {
    // Computing Height
    int h = 1;
    while (h < this.height + 1) {
      if (randomizer.binaryRandomGen()) {
        h++;
      } else {
        break;
      }
    }

    // Creating new Node
    SkipListNode newNode = new SkipListNode(num, h);

    // Increment height
    if (h > this.height) {
      this.height = h;
      this.head.next.add(this.tail);
      this.tail.next.add(null);
      this.head.height++;
      this.tail.height++;
    }
    // Finding Insert Position
    int k = this.height;

    SkipListNode pre = this.head;
    SkipListNode succ = this.tail;
    SkipListNode temp;

    ArrayList<SkipListNode> prearr = new ArrayList<>();

    while (k >= 1 && succ.value >= pre.value) {
      int level = k - 1;
      temp = pre;
      while (temp.next.get(level) != null && temp.value < succ.value) {
        if (temp.value < num) {
          pre = temp;
          temp = temp.next.get(level);
        }
        if (temp.value >= num) {
          succ = temp;
        }
      }
      prearr.add(pre);

      k--;
    }

    for (int level = 0; level < h; level++) {
      pre = prearr.get(prearr.size() - 1);
      succ = pre.next.get(level);
      pre.next.set(level, newNode);
      newNode.next.add(succ);
      prearr.remove(pre);
    }
  }

  public void print() {
    /*
     * DO NOT EDIT THIS FUNCTION
     */
    for (int i = this.height; i >= 1; --i) {
      SkipListNode it = this.head;
      while (it != null) {
        if (it.height >= i) {
          System.out.print(it.value + "\t");
        } else {
          System.out.print("\t");
        }
        it = it.next.get(0);
      }
      System.out.println("null");
    }
  }
}
