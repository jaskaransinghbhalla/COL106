// import java.util.ArrayList;
// import java.util.Collections;

public class SkipList {

  public SkipListNode head;
  public SkipListNode tail;
  public int height;
  public Randomizer randomizer;
  private final int NEG_INF = Integer.MIN_VALUE;
  private final int POS_INF = Integer.MAX_VALUE;

  SkipList() {
    /*
     * DO NOT EDIT THIS FUNCTION
     */
    this.head = new SkipListNode(NEG_INF, 1);
    this.tail = new SkipListNode(POS_INF, 1);
    this.head.next.add(0, this.tail);
    this.tail.next.add(0, null);
    this.height = 1;
    this.randomizer = new Randomizer();
  }

  public boolean delete(int num) {
    if (search(num) == false) {
      return false;
    } else {
      SkipListNode n = null;

      //   Find Node Position
      int h = this.height;

      SkipListNode pre = this.head;
      SkipListNode succ = this.tail;
      SkipListNode temp;

      while (h >= 1) {
        int level = h - 1;
        temp = pre;

        while (temp.next.get(level) != null && temp.value < succ.value) {
          if (temp.value == num) {
            n = temp;
            break;
          }
          if (temp.value < num) {
            pre = temp;
            temp = temp.next.get(level);
          }
          if (temp.value > num) {
            succ = temp;
          }
        }
        h--;
      }

      for (int level = n.height - 1; level >= 0; level--) {
        SkipListNode temp2 = this.head;
        while (temp2.next.get(level) != n) {
          temp2 = temp2.next.get(level);
        }
        temp2.next.set(level, n.next.get(level));
        if (this.head.next.get(level) == this.tail) {
          this.head.next.remove(level);
          this.tail.next.remove(level);
          this.head.height--;
          this.tail.height--;
          this.height--;
        }
      }
      return true;
    }
  }

  public boolean search(int num) {
    int h = this.height;

    SkipListNode pre = this.head;
    SkipListNode succ = this.tail;
    SkipListNode temp;

    while (h >= 1) {
      int level = h - 1;
      temp = pre;
      while (temp.next.get(level) != null && temp.value < succ.value) {
        if (temp.value == num) {
          return true;
        }
        if (temp.value < num) {
          pre = temp;
          temp = temp.next.get(level);
        }
        if (temp.value > num) {
          succ = temp;
        }
      }
      h--;
    }
    return false;
  }

  public Integer upperBound(int num) {
    SkipListNode temp = this.head;
    while (temp.next.get(0) != null) {
      if (temp.value > num) {
        return (Integer) temp.value;
      } else {
        temp = temp.next.get(0);
      }
    }
    return Integer.MAX_VALUE;
  }

  public void insert(int num) {
    int h = 1;
    while (h < this.height + 1) {
      if (randomizer.binaryRandomGen()) {
        h++;
      } else {
        break;
      }
    }
    // Creating new Node
    SkipListNode newNode = new SkipListNode(num, h);

    for (int level = 0; level < h; level++) {
      if (level + 1 > this.height) {
        this.height = level + 1;
        this.head.next.add(this.tail);
        this.tail.next.add(null);
        this.head.height++;
        this.tail.height++;
      }
      // If No Node was Present
      if (this.head.next.get(level) == this.tail) {
        this.head.next.set(level, newNode);
        newNode.next.add(this.tail);
      }
      // If Node was Present
      else {
        // Finding Location
        SkipListNode prev_node = this.head;
        SkipListNode next_node = this.head;
        while (newNode.value > next_node.value) {
          prev_node = next_node;
          next_node = next_node.next.get(level);
        }
        prev_node.next.set(level, newNode);
        newNode.next.add(next_node);
      }
    }
  }

  public void print() {
    /*
     * DO NOT EDIT THIS FUNCTION
     */
    for (int i = this.height; i >= 1; --i) {
      SkipListNode it = this.head;
      while (it != null) {
        if (it.height >= i) {
          System.out.print(it.value + "\t");
        } else {
          System.out.print("\t");
        }
        it = it.next.get(0);
      }
      System.out.println("null");
    }
  }
}
