public class BalancedBST extends BST {

  public BSTNode insertHelper(BSTNode root, int num) {
    if (root == null) {
      return new BSTNode(num);
    }
    if (num < root.value) {
      root.left = insertHelper(root.left, num);
    }
    if (num > root.value) {
      root.right = insertHelper(root.right, num);
    }
    // Root Height Maxiumum
    root.height = 1 + Math.max(height(root.left), height(root.right));
    return root;
  }

  public boolean searchHelper(BSTNode root, int num) {
    if (root == null) {
      return false;
    }
    if (num < root.value) {
      return searchHelper(root.left, num);
    }
    if (num > root.value) {
      return searchHelper(root.right, num);
    }
    if (root.value == num) {
      return true;
    }
    return false;
  }

  public BSTNode deleteHelper(BSTNode root, int num) {
    if (num > root.value) {
      root.right = deleteHelper(root.right, num);
    } else if (num < root.value) {
      root.left = deleteHelper(root.left, num);
    } else {
      // Equality

      // 0 Child
      if (root.left == null && root.right == null) {
        return null;
      }

      // 1 Child
      if (root.left == null) {
        return root.right;
      } else if (root.right == null) {
        return root.left;
      }

      //   2 Children
      BSTNode IS = findInorderSuccessor(root.right);
      root.value = IS.value;
      root.right = deleteHelper(root.right, IS.value);
    }
    return root;
  }

  public static BSTNode findInorderSuccessor(BSTNode root) {
    while (root.left != null) {
      root = root.left;
    }
    return root;
  }

  public static int height(BSTNode root) {
    if (root == null) {
      return 0;
    }
    return root.height;
  }

  public static int getBalance(BSTNode root) {
    if (root == null) {
      return 0;
    }
    return height(root.left) - height(root.right);
  }

  public static BSTNode rightRotate(BSTNode y) {
    BSTNode x = y.left;
    BSTNode T2 = x.right;

    // Perform Rotation
    x.right = y;
    y.left = T2;

    // Update heights
    y.height = Math.max(height(y.left), height(y.right)) + 1;
    x.height = Math.max(height(x.left), height(x.right)) + 1;

    // Return new Root
    return x;
  }

  public static BSTNode leftRotate(BSTNode x) {
    BSTNode y = x.right;
    BSTNode T2 = y.left;

    // Perform Rotation
    y.left = x;
    x.right = T2;

    // Update heights
    x.height = Math.max(height(x.left), height(x.right)) + 1;
    y.height = Math.max(height(y.left), height(y.right)) + 1;

    // Return new Root
    return y;
  }

  public void insert(int key) {
    root = insertHelper(root, key);
    // Get Root's Balance Factor
    int bf = getBalance(root);

    // Left Left Case
    if (bf > 1 && key < root.left.value) {
      root = rightRotate(root);
    }

    // Right Right Case
    if (bf < -1 && key > root.right.value) {
      root = leftRotate(root);
    }

    // Left Right Case
    if (bf > 1 && key > root.left.value) {
      root.left = leftRotate(root.left);
      root = rightRotate(root);
    }

    // Right Left Case
    if (bf < -1 && key < root.right.value) {
      root.right = rightRotate(root.right);
      root = leftRotate(root);
    }
  }

  public boolean delete(int key) {
    if (root == null) {
      return false;
    }
    root = deleteHelper(root, key);
    return searchHelper(root, key);
  }

  public static void main(String[] args) {
    BalancedBST b = new BalancedBST();
    b.insert(10);
    b.insert(20);
    b.insert(30);
    b.insert(40);
    b.insert(50);
    b.insert(25);
    b.preorder();
    for (int i = 0; i < b.preorder().size(); i++) {
      System.out.print(b.preorder().get(i) + " ");
    }
    System.out.println();
    b.delete(30);
    b.preorder();
    for (int i = 0; i < b.preorder().size(); i++) {
      System.out.print(b.preorder().get(i) + " ");
    }
  }
}
