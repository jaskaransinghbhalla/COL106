import java.io.*;
import java.util.*;

public class SnakesLadder {
	
	int N, M;
	int snakes[];
	int ladders[];
	
	public SnakesLadder()throws Exception{
		File file = new File("input.txt");
		BufferedReader br = new BufferedReader(new FileReader(file));
		N = Integer.parseInt(br.readLine());
        
        M = Integer.parseInt(br.readLine());

	    snakes = new int[N];
		ladders = new int[N];
	    for (int i = 0; i < N; i++){
			snakes[i] = -1;
			ladders[i] = -1;
		}

		for(int i=0;i<M;i++){
            String e = br.readLine();
            StringTokenizer st = new StringTokenizer(e);
            int source = Integer.parseInt(st.nextToken());
            int destination = Integer.parseInt(st.nextToken());

			if(source<destination){
				ladders[source] = destination;
			}
			else{
				snakes[source] = destination;
			}
        }
	}
    
	int OptimalMoves()
	{
		/* Complete this function and return the minimum number of moves required to win the game. */
	}

	int Query(int x, int y)
	{
		/* Complete this function and 
			return +1 if adding a snake/ladder from x to y improves the optimal solution, 
			else return -1. */
	}

	int[] FindBestNewSnake()
	{
		int result[] = {-1, -1};
		/* Complete this function and 
			return (x, y) i.e the position of snake if adding it increases the optimal solution by largest value,
			if no such snake exists, return (-1, -1) */

		return result;
	}

    public static void main(String[] args) throws Exception
	{
        SnakesLadder obj = new SnakesLadder();
		int a = obj.OptimalMoves();
		int b = obj.Query(10, 20);
		int c[] = new int[2];
		c = obj.FindBestNewSnake();
	}
}
