package Includes;

public class NullKeyException extends Exception{
    public NullKeyException() {  
        System.out.println("NullKey"); 
    }  
}  